// w1.dart

import 'package:eticaret/main.dart';
import 'package:eticaret/w2.dart';
import 'package:eticaret/w3.dart';
import 'package:flutter/material.dart';

class W1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'W1',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String selectedMenuItem = 'Anasayfa'; // Başlangıçta Anasayfa seçili olsun
  bool isMenuOpen = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'W1',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.brown[700],
        actions: [
          IconButton(
            icon: CircleAvatar(
              backgroundImage: AssetImage('assets/images/software.jpg'),
            ),
            onPressed: () {
              setState(() {
                isMenuOpen = !isMenuOpen;
              });
            },
          ),
        ],
        centerTitle: true,
        toolbarHeight: 80,
      ),
      body: Container(
        color: Colors.grey,
        child: Padding(
          padding: const EdgeInsets.only(top: 20),
          child: Center(
            child: GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 1,
              ),
              itemCount: 8,
              itemBuilder: (context, index) {
                return ElevatedButton(
                  onPressed: () {
                    onBoxPressed(index);
                  },
                  style: ElevatedButton.styleFrom(
                    primary: getBoxColor(index),
                    padding: EdgeInsets.all(16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text(
                    getBoxName(index),
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
      drawer: isMenuOpen ? buildMenu() : null,
    );
  }

  Color getBoxColor(int index) {
    switch (index) {
      case 0:
        return Colors.red;
      case 1:
        return Colors.green;
      case 2:
        return Colors.indigoAccent;
      case 3:
        return Colors.brown;
      case 4:
        return Colors.orange;
      case 5:
        return Colors.purple;
      case 6:
        return Colors.teal;
      case 7:
        return Colors.pink;
      default:
        return Colors.grey;
    }
  }

  String getBoxName(int index) {
    switch (index) {
      case 0:
        return 'Beyaz Eşya';
      case 1:
        return 'Mobilya';
      case 2:
        return 'Laptoplar';
      case 3:
        return 'Telefonlar';
      case 4:
        return 'Aksesuar';
      case 5:
        return 'Giyim';
      case 6:
        return 'Kitaplar';
      case 7:
        return 'Kırtasiye/Ofis';
      default:
        return 'Bilinmeyen';
    }
  }

  Widget buildMenu() {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundImage: AssetImage('assets/images/software.jpg'),
                ),
                SizedBox(width: 10),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Menü Başlığı',
                      style: TextStyle(color: Colors.white, fontSize: 14),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Alt Başlık',
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
          ListTile(
            title: Text('Anasayfa'),
            onTap: () {
              onMenuItemSelected('Anasayfa');
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MyApp()),
              );
            },
          ),
          ListTile(
            title: Text('W1'),
            onTap: () {
              onMenuItemSelected('W1');
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => W1()),
              );
            },
          ),
          ListTile(
            title: Text('W2'),
            onTap: () {
              onMenuItemSelected('W2');
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => W2()),
              );
            },
          ),
          ListTile(
            title: Text('W3'),
            onTap: () {
              onMenuItemSelected('W3');
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => W3()),
              );
            },
          ),
        ],
      ),
    );
  }

  void onMenuItemSelected(String value) {
    setState(() {
      selectedMenuItem = value;
      isMenuOpen = false;
    });
  }

  void onBoxPressed(int index) {
    print('Kutu $index tıklandı.');
  }
}
