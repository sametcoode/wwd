package com.example.eticaret

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
